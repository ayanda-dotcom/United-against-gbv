# United Against GBV — Website Prototype

Open `index.html` in a browser to view the complete responsive prototype.

Included:
- Responsive landing page
- Global network/map concept
- Organization filters
- Resource hub
- Campaigns
- Stories section
- Get Help section
- Safety-by-design section
- Join/profile modal
- Quick-exit button
- Accessible semantic HTML and no external dependencies

Important:
- Organizations, statistics, campaign progress, and map pins are demo data.
- The form does not transmit or store information.
- The help directory needs verified, current local resources before production use.
- For production, add a secure backend, authentication, verified organization workflow, moderation, privacy controls, database, search, country-specific support directory, and secure messaging.
